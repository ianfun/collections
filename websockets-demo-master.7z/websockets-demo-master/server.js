const fs = require('fs');
const url = require('url');
const ws = require("websocket");
global.arr = new Buffer.alloc(3072/*4*32*24*/);
global.clients = {};
global.timer = Date.now();

var server = require('http').createServer((req, res) => {
	switch (url.parse(req.url)) {
		case "/favicon.ico":
	    	res.setHeader('Content-Type', 'image/x-icon');
    		fs.createReadStream("favicon.ico").pipe(res);
    	default:
    		res.setHeader('Content-Type', 'text/html');
    		fs.createReadStream("game.html").pipe(res);
    }
})
wsServer = new ws.server({
		httpServer: server
});

wsServer.on('request', request => {
    let connection = request.accept('game', request.origin);
    let color = Math.floor(Math.random()*0xFFFF) | 1;
    clients[connection.socket.remoteAddress] = connection;
    connection.on('message', (m) => {
    	for(let i=0;i<m.binaryData.length-4;i+=4){
			let c = m.binaryData.readUInt32BE(i)*32 + m.binaryData.readUInt32BE(i+4)*0x4;
    		global.arr.writeUInt32BE(color, c);
    		setTimeout(()=>{arr.writeUInt32BE(0, c);}, 1000);
    	}
        connection.sendBytes(global.arr);
    });
    connection.on("close", ()=>{delete clients[connection];})
});
console.log("server listen at http://127.0.0.1:8080");
server.listen(8080);
