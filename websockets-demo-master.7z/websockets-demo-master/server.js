const http = require('http');
const fs = require('fs');
const url = require('url');
const ws = require("websocket");

global.arr = new Buffer.alloc(3072/*4*32*24*/);

var server = http.createServer((req, res) => {
	const r = url.parse(req.url);
	switch (r) {
		case "/favicon.ico":
	    	res.setHeader('Content-Type', 'image/x-icon');
    		fs.createReadStream("favicon.ico").pipe(res);
    	default:
    		res.setHeader('Content-Type', 'text/html');
    		fs.createReadStream("game.html").pipe(res);
    }
})
wsServer = new ws.server({
		httpServer: server
});
var timer = Date.now()
wsServer.on('request', request => {
    let connection = request.accept('game', request.origin);
    console.log(connection.remoteAddress);
    connection.on('message', (m) => {
			let c = m.binaryData.readUInt32BE(0x0)*32 + m.binaryData.readUInt32BE(0x4)*0x4;
    	arr.writeUInt32BE(0x1,  c);
        connection.sendBytes(global.arr);
				setTimeout(()=>{arr.writeUInt32BE(0, c);}, 1000);
    });
    connection.on('close', (reasonCode, description) => {
        console.log("client closed");
    });
});
console.log("server at http://127.0.0.1:8080");
server.listen(8080);
