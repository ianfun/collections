from hashlib import sha1
from binascii import b2a_base64

def key(j: bytes)->bytes:
  return b2a_base64(
    sha1(j+b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"). digest()
  )

print(
key(b"vDJK2hgGUHeVDSXRDYeAEw==")
)
print(b"tjloVFK8w9BH5RxPicVb03W3Ams=")