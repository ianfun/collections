struct entry keywords[] = {
  "div", DIV,
  "mod", MOD,
   NULL, 0
};
void init(){
  for(struct entry *p=keywords;p->token;p++)
    insert(p->lexptr, p->token);
}