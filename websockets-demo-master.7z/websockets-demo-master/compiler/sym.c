#define STRMAX 999
#define SYMMAX 100

char lexemes[STRMAX];
struct entry symtable[SYMMAX];
int lastentry=0;

int lookup(char *s){
  for(int p=lastentry;p>0;p--)
    if (strcmp(symtable[p].lexptr, s==0))
      return p;
  return 0;
}

int insert(char *s, int tok){
  size_t len=strlen(s);
  if (lastentry+1 >= SYMMAX) 
    error("symtable too full");
  if (lastchar+1 >= STRMAX)
    error("lex array full");
  symyable[++ lastentry].token=tok;
  symyable[lastentry].lexptr=&lexemes[lastchar+1];
  lastchar+=(int)len+1;
  strcpy(symyable[lastentry].lexptr, s);
  return lastentry;
}