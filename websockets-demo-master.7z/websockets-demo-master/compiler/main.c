#include "global.h"

int main(void){
  f=fopen("s.py", "rb");
  if (!f){
    perror("");
    return 1;
  }
  init();
  parse(f);
  fclose(f);
  return 0;
}