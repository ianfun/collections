int lookhead;
void error(char *m){
  fprintf(stderr, "line %d: %s", lineno, m);
  exit(1);
}
void emit(int t, int tval){
  switch (t){
    case '+': case '-':
    case '*': case '/':
      printf("%c\n", t);
    case DIV:
      puts("DIV");
      break;
    case MOD:
      puts("MOD");
      break;
    case NUM:
      printf("%d\n", tval);
      break;
    case ID:
      printf("%s\n", symtable[tval].lexptr);
      break;
    default:
      printf("token %d, val %d\n", t, tval);
  }
}

void parse(){
  lookhead=lexan();
  while (lookahead!=TEOF){
    expr();match(';');
  }
}

void expr(){
  int t;
  term();
  for(;;){
    switch (lookahead){
      case '+':case '-':
        t = lookahead;match(lookhead);term();emit(t, NONE);
        continue;
      default:
        return;
    }
  }
}

void term(){
  int t;
  factor();
  for(;;){
    switch (lookahead){
      case '*':case '/':case DIV:case MOD:
        t = lookahead;match(lookhead);
        facter();emit(t, NONE);
        continue;
      default:
        return;
    }
  }
}

void facter(){
    switch (lookahead){
      case '(':
        match('(');expr();match(')');
      break;
      case NUM:
        emit(NUM, tokenval);
        match(NUM);
        break;
      case ID:
        emit(ID, tokenval);
        match(ID);
        break;
      default:
        error("syntax error: factor");
    }
}

void match(int t){
  if (lookahead==t)
    lookahead=lexan();
  else
    error("syntax error: no match");
}