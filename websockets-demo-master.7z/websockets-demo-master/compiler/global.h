#include <stdio.h>
#include <ctypes.h>
#include <stdlib.h>
enum {
  BSIE=700, 
  NONE=-1, 
  EOS='\0', 
  NUM=256,
  DIV,
  MOD,
  ID,
  NONE
};

int tokenbal, lineno;
struct entry {
  char * lexptr;
  int token;
} symtable[];

void emit(int t, int tval);
int lookup(char *s);
int insert(char *s, int tok);
void init();
int lexan();
void parse();
void term();
void factor();
int main();