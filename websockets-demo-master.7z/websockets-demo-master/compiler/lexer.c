#define BSIZE 200
char lexbuf[BSIZE];

int lexan(){
  int c;
  for(;;){
    c=fgetc(f);
    switch (c){
      case ' ':
      case '\t':
        ++column;
        continue;
      case '\n':
        ++lineno;
      case EOF:
         return DONE;
      default:
        if (isalpha(c)){
          char *p=lexbuf;
          *p++=c;
          do {
            *p++=getchar();
          while (isalnum(c));
          *p=0;
          tok_char=lexbuf;
          return ID;
        }
        if (isdigit(c)){
          fscanf(f, "%d", &tok_num);
          return NUM;
        }
        tok_num=c;
        return ERROR;
    }
  }
}